public class StackException extends RuntimeException {
    StackException(String msg) {
        super(msg);
    }
}
